<!--Footer-part-->

<div class="row-fluid">
  <div id="footer" class="span12"> 2013 &copy; E-commerce Admin. </div>
</div>

<!--end-Footer-part-->