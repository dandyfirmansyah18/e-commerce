<?php /* F:\xampp\htdocs\laravel\sample5.8\resources\views/layouts/adminLayout/admin_footer.blade.php */ ?>
<!--Footer-part-->

<div class="row-fluid">
  <div id="footer" class="span12"> 2013 &copy; E-commerce Admin. </div>
</div>

<!--end-Footer-part-->