<?php /* F:\xampp\htdocs\laravel\sample5.8\resources\views/pages/cms_page.blade.php */ ?>
<?php $__env->startSection('content'); ?>
	
<section>
	<div class="container">
		<div class="row">
			<div class="col-sm-3">
				<?php echo $__env->make('layouts.frontLayout.front_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</div>
			
			<div class="col-sm-9 padding-right">
				<div class="features_items"><!--features_items-->
					<h2 class="title text-center"><?php echo e($cmsPageDetails->title); ?></h2>
					<p><?php echo e($cmsPageDetails->description); ?></p>
				</div><!--features_items-->
			</div>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontLayout.front_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>